package casopractico1;
public class Archivo {
    
}
